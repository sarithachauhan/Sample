package com.pack;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.pack.model.Account;
import com.pack.model.Corporate;
import com.pack.model.User;
import com.pack.repository.AccountRepository;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class AccountRepositoryTests {
	private static final Corporate corporate = null;


	@Autowired
	AccountRepository accountRepository;
	
	
	static Account account;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		account=new Account(12345,corporate,"virtusa1","Hyderabad","Rupees",5000.0,true);
	}
	
	@AfterAll
	static void tearDownAfterClass() throws Exception {
		account = null;
	}

	
	@Test
	public void saveAccountTests() {
		Account accObj = accountRepository.save(account);
		Assertions.assertEquals(accObj.getAccountNumber(), account.getAccountNumber());
	}

	@Test
	public void findByAccountnumberTests() {
		Account Obj =accountRepository.findByAccountNumber(account.getAccountNumber());
		Assertions.assertEquals(12345, Obj.getAccountNumber());
	}

	

	@Test
	public void deleteAccount() {
		Account obj = accountRepository.findById(account.getAccountNumber()).get();
		obj.setActive(false);
		Account obj2 = accountRepository.save(obj);
		Assertions.assertFalse(obj2.isActive());
	}


	
	
	
	
	
	
}
