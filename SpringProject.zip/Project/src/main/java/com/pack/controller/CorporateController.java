package com.pack.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.model.Corporate;
import com.pack.service.CorporateServiceImpl;

@Controller
public class CorporateController {
	@Autowired
	CorporateServiceImpl service;

	@RequestMapping("/deleteCorporate")
	public String deleteCorporate(@RequestParam("id") int id) {
		service.deleteCorporate(id);
		return "redirect:/viewCorporates";
	}

	@RequestMapping("/editform")
	public String editForm(@RequestParam("id") int id, Model m) {
		Corporate obj = service.getCorporate(id);
		m.addAttribute("corporateBean", obj);

		return "editform";
	}

	@RequestMapping("/editCorporate")
	public String editCorporate(@ModelAttribute("corporateBean") Corporate corporateBean) {
		int i = service.updateCorporate(corporateBean);
		return "redirect:/viewCorporates";

	}

	@RequestMapping("/adduserform")
	public String addUser(Model m) {
		m.addAttribute("corporateBean", new Corporate());
		return "corporateform";
	}

	@RequestMapping("/addCorporate")
	public String addCorporate(@ModelAttribute("corporateBean") Corporate corporateBean) {
		int i = service.addCorporate(corporateBean);
		return "redirect:/viewCorporates";
	}
}
