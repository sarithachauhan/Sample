package com.pack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.model.Admin;
import com.pack.model.Corporate;
import com.pack.service.CorporateServiceImpl;
import com.pack.service.UserService;

@Controller
public class AdminController {
	@Autowired
	UserService service;

	@Autowired
	CorporateServiceImpl corporateService;

	@RequestMapping("/adminlogin")
	public String adminLogin() {
		return "adminlogin";
	}

	@RequestMapping("/adminLoginPage")
	public String adminLogin(@RequestParam("username") String username, @RequestParam("password") String password,
			Model m) {
		Admin admin = service.adminAuthunticate(username, password);
		m.addAttribute("admindetails", admin);
		return "adminHome";
	}

	@RequestMapping("/adminHome")
	public String adminHome() {
		return "adminHome";
	}

	@RequestMapping("/viewCorporates")
	public String viewCorporates(Model m) {

		List<Corporate> list = corporateService.getAllRecords();
		m.addAttribute("corporateList", list);
		return "viewCorporates";
	}

}
