package com.pack.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.pack.model.Account;
import com.pack.model.Corporate;
import com.pack.service.AccountService;
import com.pack.service.CorporateService;

@Controller
public class AccountController {

	@Autowired
	AccountService service;

	@Autowired
	CorporateService corService;

	@RequestMapping("/getAccountDetails")
	public String getAccountDetails() {
		return "getAccountDetails";
	}

	@RequestMapping("/getAccounts")
	public String getAccounts(@RequestParam("id") String id, Model m) {
		m.addAttribute("id", id);
		return "getAccounts";
	}

	@RequestMapping("/addaccform")
	public String addAccForm(Model m) {
		m.addAttribute("accBean", new Account());
		return "AccountForm";
	}

	@RequestMapping("/addAccount")
	public String addAccount(@ModelAttribute("accBean") Account accBean) {
		int i = service.addAccount(accBean);
		Corporate name = corService.getCorporate(accBean.getCorporateId());
//		m.addAttribute("id", name.getCorporateName());
		return "redirect:/getAccounts?id=" + name.getCorporateName();
	}

	@RequestMapping("/closeAccount")
	public String closeAccount(@RequestParam("id") long id, @RequestParam("corname") String corname, Model m) {
		int i = service.closeAccount(id);
		m.addAttribute("id", corname);
		return "getAccounts";
	}

}
