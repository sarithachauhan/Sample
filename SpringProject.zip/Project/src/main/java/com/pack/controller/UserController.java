package com.pack.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pack.model.Account;
import com.pack.model.Corporate;
import com.pack.model.User;
import com.pack.service.AccountService;
import com.pack.service.CorporateService;
import com.pack.service.UserService;

@Controller
public class UserController {
	User obj = new User();

	@Autowired
	UserService service;
	@Autowired
	AccountService accService;
	@Autowired
	CorporateService corService;

	@RequestMapping("/")
	public String indexPage() {
		return "index";
	}

	@RequestMapping("/login")
	public String loginPage() {
		return "login";
	}

	@RequestMapping("/loginAuthunticate")
	public ModelAndView loginAuthunticate(@RequestParam("user") String user, @RequestParam("pass") String pass) {
		obj = service.loginAuthunticate(user, pass);
		System.out.println(obj + " Obj");
		if (obj != null && obj.getStatus().equalsIgnoreCase("F") && obj.getActivestatus().equalsIgnoreCase("active")) {
			return new ModelAndView("resetpassword", "userData", obj.getLogin_id());
		} else if (obj != null && obj.getActivestatus().equalsIgnoreCase("active")) {
			return new ModelAndView("accountsummary", "userData", obj.getCorporate_id());
		} else {
			return new ModelAndView("login", "message", "***Invalid Username Or Password...!!!");
		}
	}

	@RequestMapping("/addResetPassword")
	public ModelAndView addResetPassword(@RequestParam("pass") String pass,
			@RequestParam("confirmPass") String confirmPass) {
		// System.out.println(obj + " reset");
		int i = service.resetPassword(pass, confirmPass, obj.getLogin_id());
		if (i >= 1) {
			return new ModelAndView("login", "message", "***Reset Password Successfully Completed...!!!!");
		} else {
			return new ModelAndView("resetpassword", "message", "***Invalid Password Confirmation...!!!!");
		}
	}

	@RequestMapping("/accountDetails")
	public ModelAndView accountDetails(@RequestParam("id") long id) {
		Account acc = accService.accountDetails(id);
		return new ModelAndView("accountDetails", "acc", acc);
	}

	@RequestMapping("/getUsers")
	public String getUsers() {
		return "getUsers";
	}

	@RequestMapping("/userList")
	public String userList(@RequestParam("id") String id, Model m) {
		m.addAttribute("id", id);
		return "userList";
	}

	@RequestMapping("/registerUser")
	public String registerUser(Model m) {
		m.addAttribute("userBean", new User());
		return "registerUser";
	}

	@RequestMapping("/addUserDetails")
	public String addUserDetails(@ModelAttribute("userBean") User userBean, Model m) {
		int i = service.addUserDetails(userBean);
		Corporate name = corService.getCorporate(userBean.getCorporate_id());
		if (i == 0) {
			m.addAttribute("message", "***Please Provide Correct Information....!!!!");
			return "registerUser";
		} else {
			return "redirect:/userList?id=" + name.getCorporateName();
		}
	}

	@RequestMapping("/updateUserDetails")
	public String updateUserDetails(@RequestParam("id") long id, @RequestParam("corId") long corId, Model m) {
		User user = service.getUser(id);
		System.out.println(user);
		m.addAttribute("userBean", user);
		return "updateUserDetails";
	}

	@RequestMapping("/updateUser")
	public String updateUser(@ModelAttribute("userBean") User userBean) {
		System.out.println(userBean);
		service.updateUser(userBean);
		Corporate name = corService.getCorporate(userBean.getCorporate_id());
		return "redirect:/userList?id=" + name.getCorporateName();
	}

	@RequestMapping("/deleteUser")
	public String deleteUser(@RequestParam("id") long id, @RequestParam("corId") long corId) {
		service.deleteUser(id);
		Corporate name = corService.getCorporate(corId);
		return "redirect:/userList?id=" + name.getCorporateName();
	}
}
