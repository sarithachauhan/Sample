package com.pack.service;

import java.util.List;

import com.pack.model.Corporate;

public interface CorporateService {
	public List<Corporate> getAllRecords();

	public void deleteCorporate(int id);

	public int updateCorporate(Corporate corporate);

	public Corporate getCorporate(long l);

	public int addCorporate(Corporate corporate);

	public Corporate getCorporateByName(String name);
}
