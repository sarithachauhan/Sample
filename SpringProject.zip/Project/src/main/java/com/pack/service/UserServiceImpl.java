package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.dao.UserDao;
import com.pack.model.Admin;
import com.pack.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao dao;

	@Override
	public User loginAuthunticate(String user, String pass) {
		User obj = dao.loginAuthunticate(user, pass);
		return obj;
	}

	@Override
	public int resetPassword(String pass, String confirmPass, long id) {
		if (pass.equals(confirmPass)) {
			return dao.resetPassword(pass, id);
		} else {
			return 0;
		}
	}

	@Override
	public Admin adminAuthunticate(String user, String pass) {
		return dao.adminAuthenticate(user, pass);
	}

	@Override
	public int addUserDetails(User user) {
		return dao.addUserDetails(user);
	}

	@Override
	public User getUser(long id) {
		return dao.getUser(id);
	}

	@Override
	public int updateUser(User user) {
		return dao.updateUser(user);
	}

	@Override
	public void deleteUser(long id) {
		dao.deleteUser(id);
	}

}
