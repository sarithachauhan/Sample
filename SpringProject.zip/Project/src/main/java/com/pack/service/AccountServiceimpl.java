package com.pack.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.dao.AccountDao;
import com.pack.model.Account;

@Service
public class AccountServiceimpl implements AccountService {
	@Autowired
	AccountDao dao;

	@Override
	public Account accountDetails(long accountNo) {
		return dao.getAccount(accountNo);
	}

	@Override
	public int closeAccount(long id) {
		return dao.closeAccount(id);
	}

	@Override
	public int addAccount(Account acc) {
		return dao.addAccount(acc);
	}

}
