package com.pack.service;

import com.pack.model.Admin;
import com.pack.model.User;

public interface UserService {

	public User loginAuthunticate(String user, String pass);

	public int resetPassword(String pass, String confirmPass, long l);

	public Admin adminAuthunticate(String user, String pass);

	public int addUserDetails(User user);

	public User getUser(long id);

	public int updateUser(User user);

	public void deleteUser(long id);
}
