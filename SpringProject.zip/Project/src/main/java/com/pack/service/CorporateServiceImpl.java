package com.pack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.dao.CorporateDao;
import com.pack.model.Corporate;

@Service
public class CorporateServiceImpl implements CorporateService {
	@Autowired
	CorporateDao dao;

	@Override
	public List<Corporate> getAllRecords() {
		return dao.getAllRecords();
	}

	@Override
	public void deleteCorporate(int id) {
		dao.deleteCorporate(id);

	}

	@Override
	public int updateCorporate(Corporate corporate) {
		return dao.updateCorporate(corporate);
	}

	@Override
	public Corporate getCorporate(long id) {
		return dao.getCorporate(id);
	}

	@Override
	public int addCorporate(Corporate corporate) {
		return dao.addCorporate(corporate);
	}

	@Override
	public Corporate getCorporateByName(String name) {
		return dao.getCorporateByName(name);
	}

}
