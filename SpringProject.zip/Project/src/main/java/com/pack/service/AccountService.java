package com.pack.service;

import com.pack.model.Account;

public interface AccountService {
	public Account accountDetails(long accountNo);

	public int addAccount(Account acc);

	public int closeAccount(long id);
}
