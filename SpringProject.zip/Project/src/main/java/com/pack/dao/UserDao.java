package com.pack.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.pack.model.Admin;
import com.pack.model.Corporate;
import com.pack.model.User;

@Repository
public class UserDao {

	@Autowired
	JdbcTemplate jdbc;

	public User loginAuthunticate(String user, String pass) {
		String sql = "select * from user where username=? and password=?";
		User userObj = null;
		try {
			userObj = (User) jdbc.queryForObject(sql, new Object[] { user, pass },
					new BeanPropertyRowMapper(User.class));
		} catch (EmptyResultDataAccessException e) {
			return userObj;
		}

		// System.out.println(userObj.getUsername() + " " + userObj.getPassword());
		return userObj;

	}

	public int resetPassword(String pass, long id) {
		System.out.println(id);
		String sql = "update user set password=?,status='NO' where login_id=" + id;
		int i = jdbc.update(sql, pass);
		return i;
	}

	public Admin adminAuthenticate(String user, String pass) {
		Admin admin = null;
		String sql = "select * from login where username=? and password=?";
		try {
			admin = (Admin) jdbc.queryForObject(sql, new Object[] { user, pass },
					new BeanPropertyRowMapper(Admin.class));
		} catch (EmptyResultDataAccessException e) {
			return admin;
		}
		System.out.println(admin);
		return admin;
	}

	public int addUserDetails(User user) {
		String sql = "INSERT INTO `project`.`user` (`corporate_id`, `login_id`, `username`, `department`, `address`, `mobilenumber`, `password`,`status`,`activestatus`) VALUES (?,?,?,?,?,?,?,?,?)";
		return jdbc.update(sql, user.getCorporate_id(), user.getLogin_id(), user.getUsername(), user.getDepartment(),
				user.getAddress(), user.getMobileNumber(), user.getPassword(), "F", "active");
	}

	public User getUser(long id) {
		String sql = "select * from user where login_id=?";
		return (User) jdbc.queryForObject(sql, new Object[] { id }, new BeanPropertyRowMapper(User.class));
	}

	public int updateUser(User user) {
		String sql = "update user set department=?,address=?,mobilenumber=? where login_id=?";
		return jdbc.update(sql, user.getDepartment(), user.getAddress(), user.getMobileNumber(), user.getLogin_id());
	}

	public void deleteUser(long id) {
		String sql = "update user set activestatus='close', status='F' where login_id=?";
		jdbc.update(sql, id);
	}
}
