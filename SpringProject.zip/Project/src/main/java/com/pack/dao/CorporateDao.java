package com.pack.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.pack.model.Corporate;

@Repository
public class CorporateDao {
	@Autowired
	JdbcTemplate jdbc;

	public List<Corporate> getAllRecords() {
		String sql = "select * from corporate_setup where status='active'";

		return jdbc.query(sql, new BeanPropertyRowMapper<Corporate>(Corporate.class));
	}

	public void deleteCorporate(int id) {
		String sql = "update corporate_setup set status='close' where corporate_id=?";
		jdbc.update(sql, new Object[] { id });
	}

	public Corporate getCorporate(long id) {
		String sql = "select * from corporate_setup where corporate_id=?";
		return (Corporate) jdbc.queryForObject(sql, new Object[] { id }, new BeanPropertyRowMapper(Corporate.class));
	}

	public Corporate getCorporateByName(String name) {
		String sql = "select * from corporate_setup where corporate_name=?";
		return (Corporate) jdbc.queryForObject(sql, new Object[] { name }, new BeanPropertyRowMapper(Corporate.class));
	}

	public int updateCorporate(Corporate corporate) {
		String sql = "update corporate_setup set address=?,phonenumber=? where corporate_id=?";
		return jdbc.update(sql,
				new Object[] { corporate.getAddress(), corporate.getPhoneNumber(), corporate.getCorporateId() });
	}

	public int addCorporate(Corporate corporate) {
		String sql = "insert into corporate_setup(corporate_name,address,phonenumber,status)  values(?,?,?,?)";
		return jdbc.update(sql, new Object[] { corporate.getCorporateName(), corporate.getAddress(),
				corporate.getPhoneNumber(), "active" });
	}
}
