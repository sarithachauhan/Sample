package com.pack.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.pack.model.Account;

@Repository
public class AccountDao {
	@Autowired
	JdbcTemplate jdbc;

	public Account getAccount(long id) {
		String sql = "select * from account_setup where account_number=?";
		Account acc = (Account) jdbc.queryForObject(sql, new Object[] { id }, new BeanPropertyRowMapper(Account.class));
		System.out.println(acc);
		return acc;

	}

	public int addAccount(Account acc) {
		String sql = "insert into account_setup(account_number,corporate_id,account_name,branch,currency,available_balance,status)  values(?,?,?,?,?,?,?)";
		return jdbc.update(sql, acc.getAccountNumber(), acc.getCorporateId(), acc.getAccountName(), acc.getBranch(),
				acc.getCurrency(), acc.getAvailableBalance(), "active");
	}

	public int closeAccount(long id) {
		String sql = "update account_setup set status='close' where account_number=?";
		return jdbc.update(sql, id);
	}
}
